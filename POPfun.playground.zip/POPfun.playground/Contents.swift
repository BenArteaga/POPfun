import UIKit

protocol Spaceship: CustomStringConvertible {
    //get set means that it is a read/write property
    var isFlying: Bool { get set}
    var make: String { get set }
    var model: String { get set }
    mutating func launch()
    mutating func land()
}

//the reason for this extension is that now TIEFighter and MilleniumFalcon can assess these functions so we don't need to repeat any code
//being able to extend protocols is extremely useful when wanting certain functionality that the Swift Standard Library doesn't offer
extension Spaceship {
    var makeModel: String {
        return "\(make) \(model)"
    }
    
    mutating func launch() {
        if isFlying {
            print("Already flying")
        }
        else {
            isFlying = true
            print("\(self.description) blasted off!")
        }
    }
    
    mutating func land() {
        if isFlying {
            isFlying = false
            print("\(self.description) landed")
        }
        else {
            print("already landed")
        }
    }
}

struct TIEFighter: Spaceship {
    var isFlying: Bool = false
    var make: String
    var model: String
    
    var description: String {
        return self.makeModel
    }
}

class MilleniumFalcon: Spaceship {
    var isFlying: Bool = false
    var make: String
    var model: String
    
    init(isFlying: Bool, make: String, model: String) {
        self.isFlying = isFlying
        self.make = make
        self.model = model
    }
    
    var description: String {
        return self.makeModel
    }
    
    func fireLasers() {
        print("pew pew pew")
    }
}

var tieFighter = TIEFighter(isFlying: false, make: "TIE", model: "Fighter")
var milleniumFalcon = MilleniumFalcon(isFlying: false, make: "Millenium", model: "Falcon")

tieFighter.launch()
milleniumFalcon.launch()
milleniumFalcon.fireLasers()

var spaceshipArray: Array<Spaceship> = [tieFighter, milleniumFalcon]

for spaceship in spaceshipArray {
    print("\(spaceship.description)")
}
